test = {   'name': 'q3d',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> np.random.seed(88);\n>>> pivotal_freq == sum(simtable.column("pivot20"))/ntrials\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
