test = {   'name': 'q3d',
    'points': 1,
    'suites': [{'cases': [{'code': '>>> pivotal_freq == sum(simtable.column("pivot20"))/ntrials\n', 'hidden': True, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
