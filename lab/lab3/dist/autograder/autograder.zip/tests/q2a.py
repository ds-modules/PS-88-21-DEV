test = {   'name': 'q2a',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> 0 <= sim <= voters2020\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.random.seed(88);\n>>> sim == np.random.binomial(n=voters2020, p=.5)\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
