test = {   'name': 'q2b',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> 0 <= joe_count <= voters2020\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> joe_count == np.random.binomial(n=voters2020, p=.513)\n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
