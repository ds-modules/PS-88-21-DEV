test = {   'name': 'q4a',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> group2pivotal == sum(grouptrials.column("voter piv2"))/ntrials #SOLUTION\nTrue', 'hidden': True, 'locked': False},
                                   {'code': '>>> group3pivotal == sum(grouptrials.column("voter piv3"))/ntrials\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
