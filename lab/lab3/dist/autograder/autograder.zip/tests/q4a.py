test = {   'name': 'q4a',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> np.random.seed(88);\n>>> group2pivotal == sum(grouptrials.column("voter piv2"))/ntrials #SOLUTION\nTrue', 'hidden': True, 'locked': False},
                                   {'code': '>>> np.random.seed(88);\n>>> group3pivotal == sum(grouptrials.column("voter piv3"))/ntrials\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
