test = {   'name': 'q3e',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> np.random.seed(88);\n'
                                               '>>> assert piv_trials35 == [one_pivot(n=50, p=.55) for _ in range(ntrials)];\n'
                                               '>>> assert pivotal_freq == sum(piv_trials35)/ntrials\n',
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
